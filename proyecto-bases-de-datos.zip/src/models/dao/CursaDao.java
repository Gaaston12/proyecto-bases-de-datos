package models.dao;

public class CursaDao {
	public static final String TABLE_NAME 				= "cursa";
	public static final String TITLE_COLUMN_DNI_ALUMNO 	= TABLE_NAME + ".dni_alumno";
	public static final String TITLE_COLUMN_COD_MATERIA	= TABLE_NAME + ".cod_materia";
	
}
