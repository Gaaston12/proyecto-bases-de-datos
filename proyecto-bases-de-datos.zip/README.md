# proyecto-bases-de-datos

# Coworkers ✒️

* **Matias Lopez** - [Perfil Matias](https://github.com/Mati36)
* **Gaston Martin** - [Perfil Gaston](https://github.com/Gaaston12)
* **Nicolas Madariaga** - [Perfil Nicolas](https://github.com/NicoMadariaga)

# Configure connection and use 
1. Para configurar la conexion a la base de datos se debe modificar los parametros dentro del archivo config_db.json
2. Crear la base de datos ejecutar sql/proyecto.sql
3. Cargar datos a la base de datos ejecutar sql/carga_datos.sql
4. Realizar las consultas del ejercicio 6 ejecutar sql/consultas.sql
